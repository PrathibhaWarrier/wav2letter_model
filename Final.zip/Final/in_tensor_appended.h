
#ifndef TENSORFLOW_LITE_MICRO_EXAMPLES_WAV2LETTER_IN_TENSOR_APPENDED_H_
#define TENSORFLOW_LITE_MICRO_EXAMPLES_WAV2LETTER_IN_TENSOR_APPENDED_H_
//extern const int input_ar[1][11544];

#include <cstdint>

constexpr int g_in_tensor_appended_size = 11544;
extern const int g_in_tensor_appended[];
#endif